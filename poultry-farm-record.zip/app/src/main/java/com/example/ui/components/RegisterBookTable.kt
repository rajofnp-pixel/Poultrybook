package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DailyLog
import com.example.ui.theme.LedgerBorder
import com.example.ui.theme.LedgerDarkText
import com.example.ui.theme.LedgerHeaderGreen
import com.example.ui.theme.LedgerMutedText
import com.example.ui.theme.LedgerPaperBg
import com.example.ui.theme.LedgerRowEven
import com.example.ui.theme.LedgerRowOdd
import com.example.ui.theme.LedgerRulingLine
import com.example.ui.theme.LiveBirdsGreen
import com.example.ui.theme.MortalityRed
import com.example.util.PoultryUtils
import com.example.util.RegisterBookRow

@Composable
fun RegisterBookTable(
    rows: List<RegisterBookRow>,
    onEditRow: (RegisterBookRow) -> Unit,
    onDeleteLog: (DailyLog) -> Unit,
    onExportReportClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedRowForAction by remember { mutableStateOf<RegisterBookRow?>(null) }
    var showDeleteConfirmDialog by remember { mutableStateOf<DailyLog?>(null) }

    // Column Width Configuration
    val colAgeWidth = 85.dp
    val colDateWidth = 95.dp
    val colConsumedWidth = 145.dp
    val colRemainingWidth = 135.dp
    val colMortalityWidth = 85.dp
    val colLiveBirdsWidth = 115.dp
    val colWeightWidth = 100.dp
    val colRemarksWidth = 180.dp

    val totalTableWidth = colAgeWidth + colDateWidth + colConsumedWidth + colRemainingWidth +
            colMortalityWidth + colLiveBirdsWidth + colWeightWidth + colRemarksWidth

    // Action dialog for tapped row
    if (selectedRowForAction != null) {
        val target = selectedRowForAction!!
        AlertDialog(
            onDismissRequest = { selectedRowForAction = null },
            title = {
                Text("Day ${target.dayNumber} Record Options", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Date: ${target.formattedDate}")
                    Text("Feed Consumed: ${target.feedConsumedDisplay}")
                    Text("Live Birds: ${target.runningLiveBirds} | Mortality: ${target.dailyMortality}")
                    if (target.remarks != "—") {
                        Text("Remarks: ${target.remarks}")
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val rowToEdit = target
                        selectedRowForAction = null
                        onEditRow(rowToEdit)
                    }
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Edit Record")
                }
            },
            dismissButton = {
                Row {
                    TextButton(
                        onClick = {
                            val logToDelete = target.log
                            selectedRowForAction = null
                            showDeleteConfirmDialog = logToDelete
                        }
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Delete", color = MaterialTheme.colorScheme.error)
                    }
                    TextButton(onClick = { selectedRowForAction = null }) {
                        Text("Cancel")
                    }
                }
            }
        )
    }

    // Delete confirmation dialog
    if (showDeleteConfirmDialog != null) {
        val logToDelete = showDeleteConfirmDialog!!
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = null },
            title = { Text("Delete Day ${logToDelete.ageDays} Record?") },
            text = { Text("Are you sure you want to permanently delete this daily record? Running balances will automatically recalculate.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteLog(logToDelete)
                        showDeleteConfirmDialog = null
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = null }) {
                    Text("Keep Record")
                }
            }
        )
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("physical_register_book_table_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Table Section Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = LedgerHeaderGreen.copy(alpha = 0.12f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = LedgerHeaderGreen,
                            modifier = Modifier
                                .padding(8.dp)
                                .size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Poultry Farm Register Book",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Physical Ledger View • ${rows.size} Days Logged",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Export/Share Shortcut
                IconButton(
                    onClick = onExportReportClick,
                    modifier = Modifier.testTag("export_report_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Export Report",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Physical Ledger Hint
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.TableChart,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "Swipe horizontally to view all columns. Tap any row to edit or delete.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (rows.isEmpty()) {
                // Empty state
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(LedgerPaperBg)
                        .border(1.dp, LedgerBorder, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = LedgerMutedText,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Register Book is Ready",
                            fontWeight = FontWeight.Bold,
                            color = LedgerDarkText
                        )
                        Text(
                            text = "Enter your Day 1 record above to populate the ledger columns.",
                            style = MaterialTheme.typography.bodySmall,
                            color = LedgerMutedText,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                // Horizontally Scrollable Authentic Ledger Table
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.5.dp, LedgerHeaderGreen, RoundedCornerShape(10.dp))
                ) {
                    val horizontalScrollState = rememberScrollState()

                    Column(
                        modifier = Modifier
                            .width(totalTableWidth)
                            .horizontalScroll(horizontalScrollState)
                            .background(LedgerPaperBg)
                    ) {
                        // 1. Table Header Row (Physical Green Ledger Header)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(LedgerHeaderGreen)
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            HeaderCell("Age/Day", colAgeWidth, TextAlign.Center)
                            HeaderDivider()
                            HeaderCell("Date", colDateWidth, TextAlign.Center)
                            HeaderDivider()
                            HeaderCell("Feed Consumed", colConsumedWidth, TextAlign.Start)
                            HeaderDivider()
                            HeaderCell("Remaining Stock", colRemainingWidth, TextAlign.Start)
                            HeaderDivider()
                            HeaderCell("Mortality", colMortalityWidth, TextAlign.Center)
                            HeaderDivider()
                            HeaderCell("Live Birds", colLiveBirdsWidth, TextAlign.Center)
                            HeaderDivider()
                            HeaderCell("Body Weight", colWeightWidth, TextAlign.Center)
                            HeaderDivider()
                            HeaderCell("Remarks", colRemarksWidth, TextAlign.Start)
                        }

                        HorizontalDivider(thickness = 1.dp, color = LedgerRulingLine)

                        // 2. Data Rows
                        rows.forEachIndexed { index, row ->
                            val rowBg = if (index % 2 == 0) LedgerRowEven else LedgerRowOdd

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(rowBg)
                                    .clickable { selectedRowForAction = row }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Age/Day
                                DataCell(
                                    text = "Day ${row.dayNumber}",
                                    width = colAgeWidth,
                                    align = TextAlign.Center,
                                    fontWeight = FontWeight.Bold,
                                    color = LedgerHeaderGreen
                                )
                                CellDivider()

                                // Date
                                DataCell(
                                    text = row.formattedDate,
                                    width = colDateWidth,
                                    align = TextAlign.Center,
                                    color = LedgerDarkText
                                )
                                CellDivider()

                                // Feed Consumed
                                DataCell(
                                    text = row.feedConsumedDisplay,
                                    width = colConsumedWidth,
                                    align = TextAlign.Start,
                                    fontWeight = FontWeight.Medium,
                                    color = LedgerDarkText
                                )
                                CellDivider()

                                // Remaining Feed Stock
                                DataCell(
                                    text = "${row.remainingFeedDisplay}\n(${PoultryUtils.formatNumber(row.remainingFeedKg)} kg)",
                                    width = colRemainingWidth,
                                    align = TextAlign.Start,
                                    color = LedgerDarkText
                                )
                                CellDivider()

                                // Mortality
                                DataCell(
                                    text = if (row.dailyMortality > 0) "${row.dailyMortality}" else "0",
                                    width = colMortalityWidth,
                                    align = TextAlign.Center,
                                    fontWeight = if (row.dailyMortality > 0) FontWeight.Bold else FontWeight.Normal,
                                    color = if (row.dailyMortality > 0) MortalityRed else LedgerMutedText
                                )
                                CellDivider()

                                // Live Stock Birds
                                DataCell(
                                    text = "${row.runningLiveBirds}",
                                    width = colLiveBirdsWidth,
                                    align = TextAlign.Center,
                                    fontWeight = FontWeight.Bold,
                                    color = LiveBirdsGreen
                                )
                                CellDivider()

                                // Body Weight
                                DataCell(
                                    text = row.bodyWeightDisplay,
                                    width = colWeightWidth,
                                    align = TextAlign.Center,
                                    fontWeight = if (row.bodyWeightDisplay != "—") FontWeight.SemiBold else FontWeight.Normal,
                                    color = LedgerDarkText
                                )
                                CellDivider()

                                // Remarks
                                DataCell(
                                    text = row.remarks,
                                    width = colRemarksWidth,
                                    align = TextAlign.Start,
                                    color = LedgerMutedText
                                )
                            }

                            HorizontalDivider(thickness = 0.8.dp, color = LedgerRulingLine)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HeaderCell(
    text: String,
    width: Dp,
    align: TextAlign
) {
    Text(
        text = text,
        modifier = Modifier
            .width(width)
            .padding(horizontal = 6.dp),
        color = Color.White,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        textAlign = align
    )
}

@Composable
private fun HeaderDivider() {
    Box(
        modifier = Modifier
            .width(1.dp)
            .height(24.dp)
            .background(Color.White.copy(alpha = 0.25f))
    )
}

@Composable
private fun DataCell(
    text: String,
    width: Dp,
    align: TextAlign,
    fontWeight: FontWeight = FontWeight.Normal,
    color: Color = LedgerDarkText
) {
    Text(
        text = text,
        modifier = Modifier
            .width(width)
            .padding(horizontal = 6.dp),
        color = color,
        fontSize = 12.sp,
        fontWeight = fontWeight,
        textAlign = align,
        maxLines = 3,
        overflow = TextOverflow.Ellipsis
    )
}

@Composable
private fun CellDivider() {
    Box(
        modifier = Modifier
            .width(1.dp)
            .height(28.dp)
            .background(LedgerRulingLine)
    )
}

package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SelectableDates
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FarmGreenPrimary
import com.example.ui.theme.FeedAmber
import com.example.ui.theme.MortalityRed
import com.example.ui.viewmodel.DailyEntryFormState
import com.example.util.PoultryUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyEntryForm(
    formState: DailyEntryFormState,
    feedBagSizeKg: Double,
    onDateSelected: (Long) -> Unit,
    onFeedBagsChanged: (String) -> Unit,
    onFeedKgChanged: (String) -> Unit,
    onFeedReceivedChanged: (String) -> Unit,
    onMortalityChanged: (String) -> Unit,
    onBodyWeightChanged: (String) -> Unit,
    onBodyWeightUnitChanged: (String) -> Unit,
    onRemarksChanged: (String) -> Unit,
    onAppendRemarkTag: (String) -> Unit,
    onSaveClick: () -> Unit,
    onCancelEditClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showDatePicker by remember { mutableStateOf(false) }

    // DatePicker dialog with STRICT LOCK on future dates
    val todayMidnight = PoultryUtils.getTodayStartOfDay()
    val datePickerState = rememberDatePickerState(
        initialSelectedDateMillis = formState.logDate,
        selectableDates = object : SelectableDates {
            override fun isSelectableDate(utcTimeMillis: Long): Boolean {
                // STRICT RULE: Future dates are disabled/locked
                return utcTimeMillis <= System.currentTimeMillis()
            }
        }
    )

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { selected ->
                            onDateSelected(selected)
                        }
                        showDatePicker = false
                    }
                ) {
                    Text("Confirm Date", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(
                state = datePickerState,
                title = {
                    Text(
                        "Select Log Date",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                },
                headline = {
                    Text(
                        "Future dates are strictly locked",
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            )
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("daily_log_entry_form"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Form Header: Age/Day badge + Date picker selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Auto-calculated Age/Day Badge
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = FarmGreenPrimary,
                        modifier = Modifier.testTag("entry_day_badge")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Day ${formState.ageDays}",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = if (formState.editingLogId != null) "Edit Day Record" else "Daily Log Entry",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Auto-calculated elapsed age",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Date Picker Chip/Button
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .clickable { showDatePicker = true }
                        .testTag("date_picker_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.CalendarToday,
                            contentDescription = "Pick Date",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = PoultryUtils.formatDate(formState.logDate),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Milestone reminder for weekly body weight (e.g. Day 7, 14, 21, 28, 35...)
            val isWeeklyMilestone = formState.ageDays % 7 == 0
            if (isWeeklyMilestone) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFFF3E0),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Scale,
                            contentDescription = null,
                            tint = FeedAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Weekly Weigh-In Day! Record average bird body weight for Day ${formState.ageDays}.",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF8D3B00)
                        )
                    }
                }
            }

            // Section 1: Feed Consumed Today (Bags & KG linked)
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Feed Consumed Today (${feedBagSizeKg.toInt()} kg / bag)",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = formState.feedConsumedBags,
                        onValueChange = onFeedBagsChanged,
                        label = { Text("Feed (Bags)") },
                        placeholder = { Text("e.g. 1.5") },
                        leadingIcon = {
                            Icon(Icons.Default.Restaurant, contentDescription = null, modifier = Modifier.size(18.dp))
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("feed_consumed_bags_input")
                    )

                    OutlinedTextField(
                        value = formState.feedConsumedKg,
                        onValueChange = onFeedKgChanged,
                        label = { Text("Feed (KG)") },
                        placeholder = { Text("e.g. 75") },
                        leadingIcon = {
                            Icon(Icons.Default.Scale, contentDescription = null, modifier = Modifier.size(18.dp))
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("feed_consumed_kg_input")
                    )
                }
            }

            // Section 2: Feed Received (Optional) & Daily Mortality
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = formState.newFeedReceivedBags,
                    onValueChange = onFeedReceivedChanged,
                    label = { Text("New Feed In (Bags)") },
                    placeholder = { Text("0 (optional)") },
                    leadingIcon = {
                        Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(18.dp))
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("feed_received_input")
                )

                OutlinedTextField(
                    value = formState.dailyMortality,
                    onValueChange = onMortalityChanged,
                    label = { Text("Daily Mortality") },
                    placeholder = { Text("0") },
                    leadingIcon = {
                        Icon(
                            Icons.Default.CrisisAlert,
                            contentDescription = null,
                            tint = MortalityRed,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("daily_mortality_input")
                )
            }

            // Section 3: Body Weight (with g/kg toggle)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = formState.bodyWeightValue,
                    onValueChange = onBodyWeightChanged,
                    label = { Text("Avg Body Weight (Weekly)") },
                    placeholder = { Text(if (formState.bodyWeightUnit == "g") "e.g. 450" else "e.g. 1.8") },
                    leadingIcon = {
                        Icon(Icons.Default.Scale, contentDescription = null, modifier = Modifier.size(18.dp))
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("body_weight_input")
                )

                // Unit Toggle: Grams vs KG
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(4.dp)
                ) {
                    val isGrams = formState.bodyWeightUnit == "g"
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isGrams) FarmGreenPrimary else Color.Transparent,
                        modifier = Modifier.clickable { onBodyWeightUnitChanged("g") }
                    ) {
                        Text(
                            text = "grams",
                            color = if (isGrams) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (!isGrams) FarmGreenPrimary else Color.Transparent,
                        modifier = Modifier.clickable { onBodyWeightUnitChanged("kg") }
                    ) {
                        Text(
                            text = "kg",
                            color = if (!isGrams) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Section 4: Remarks / Notes (Vaccination, Medicine, Temperature)
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = formState.remarks,
                    onValueChange = onRemarksChanged,
                    label = { Text("Remarks / Notes (Vaccine, Medicine, Temp)") },
                    placeholder = { Text("e.g. ND/IB Vaccine, Brooder Temp 32°C") },
                    leadingIcon = {
                        Icon(Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(18.dp))
                    },
                    singleLine = false,
                    maxLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("remarks_input")
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Quick Chip Shortcuts for poultry farm actions
                Text(
                    "Quick Tags (tap to add):",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val presets = listOf(
                        "ND+IB Vaccine",
                        "Gumboro IBD",
                        "Lasota Drops",
                        "Vitamin AD3E",
                        "Electrolytes",
                        "Antibiotic Dose",
                        "Temp 32°C",
                        "Temp 28°C",
                        "Litter Raked",
                        "Normal Activity"
                    )
                    for (tag in presets) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.clickable { onAppendRemarkTag(tag) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(tag, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }

            if (formState.error != null) {
                Text(
                    text = formState.error,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            // Save / Cancel Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (formState.editingLogId != null) {
                    OutlinedButton(
                        onClick = onCancelEditClick,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Cancel Edit")
                    }
                }

                Button(
                    onClick = onSaveClick,
                    enabled = !formState.isSaving,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("save_daily_record_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (formState.editingLogId != null) "Update Record" else "Save Daily Record",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Farm Palette: Rich Green, Warm Harvest Amber, Deep Slate & Cream Ledger
val FarmGreenPrimary = Color(0xFF1B5E20)
val FarmGreenOnPrimary = Color(0xFFFFFFFF)
val FarmGreenContainer = Color(0xFFD4EED8)
val FarmGreenOnContainer = Color(0xFF04210B)

val FarmAmberSecondary = Color(0xFFD85A04)
val FarmAmberOnSecondary = Color(0xFFFFFFFF)
val FarmAmberContainer = Color(0xFFFFDBC9)
val FarmAmberOnContainer = Color(0xFF341100)

val FarmTertiary = Color(0xFF006874)
val FarmOnTertiary = Color(0xFFFFFFFF)
val FarmTertiaryContainer = Color(0xFF9EEFFD)
val FarmOnTertiaryContainer = Color(0xFF001F24)

// Surface and Backgrounds
val FarmBackground = Color(0xFFFBF9F4) // Warm eggshell / cream
val FarmSurface = Color(0xFFFFFFFF)
val FarmSurfaceVariant = Color(0xFFF0EAE1)
val FarmOnSurface = Color(0xFF1C1B1A)
val FarmOnSurfaceVariant = Color(0xFF4C463F)
val FarmOutline = Color(0xFF7E766D)
val FarmOutlineVariant = Color(0xFFD0C5B8)

// Physical Ledger Colors
val LedgerHeaderGreen = Color(0xFF1C4228)
val LedgerPaperBg = Color(0xFFFFFDF8)
val LedgerRulingLine = Color(0xFFE4DCCE)
val LedgerRowEven = Color(0xFFFFFFFF)
val LedgerRowOdd = Color(0xFFF9F7F1)
val LedgerDarkText = Color(0xFF1A202C)
val LedgerMutedText = Color(0xFF5A6270)
val LedgerBorder = Color(0xFFD6CEBF)

// Metric card accents
val LiveBirdsGreen = Color(0xFF2E7D32)
val MortalityRed = Color(0xFFC62828)
val FeedAmber = Color(0xFFE65100)
val MetricBlue = Color(0xFF0277BD)

// Dark Theme Variants
val DarkFarmGreenPrimary = Color(0xFF81C784)
val DarkFarmAmberSecondary = Color(0xFFFFB74D)
val DarkFarmBackground = Color(0xFF121411)
val DarkFarmSurface = Color(0xFF1B1E1A)
val DarkFarmSurfaceVariant = Color(0xFF272C25)

package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.PoultryDao
import com.example.data.model.DailyLog
import com.example.data.model.FlockBatch

@Database(
    entities = [FlockBatch::class, DailyLog::class],
    version = 1,
    exportSchema = false
)
abstract class PoultryDatabase : RoomDatabase() {

    abstract fun poultryDao(): PoultryDao

    companion object {
        @Volatile
        private var INSTANCE: PoultryDatabase? = null

        fun getDatabase(context: Context): PoultryDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PoultryDatabase::class.java,
                    "biraj_khan_poultry_farm.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.FlockBatch
import com.example.ui.theme.MortalityRed
import com.example.ui.viewmodel.DashboardMetrics
import com.example.util.PoultryUtils

@Composable
fun CloseBatchDialog(
    batch: FlockBatch,
    metrics: DashboardMetrics,
    onDismiss: () -> Unit,
    onConfirmClose: (String?) -> Unit
) {
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFFF3E0),
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        Icons.Default.Archive,
                        contentDescription = null,
                        tint = Color(0xFFE65100),
                        modifier = Modifier
                            .padding(8.dp)
                            .size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text("Close Current Batch?", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "Closing will safely archive this flock's register book forever on local Room SQLite memory. You can start a new batch right after.",
                    style = MaterialTheme.typography.bodyMedium
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Flock: ${batch.flockName}", fontWeight = FontWeight.Bold)
                        Text("Start Date: ${PoultryUtils.formatDate(batch.startDate)}")
                        Text("Initial Birds: ${batch.initialChicks} birds")
                        Text("Final Live Birds: ${metrics.currentLiveBirds} birds")
                        Text("Total Mortality: ${metrics.cumulativeMortality} (${PoultryUtils.formatNumber(metrics.mortalityRate)}%)")
                        Text("Total Feed Consumed: ${PoultryUtils.formatNumber(metrics.totalFeedConsumedBags)} Bags (${PoultryUtils.formatNumber(metrics.totalFeedConsumedKg)} kg)")
                        Text("Remaining Feed Stock: ${PoultryUtils.formatNumber(metrics.remainingFeedStockBags)} Bags")
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Closing / Sale Notes (optional)") },
                    placeholder = { Text("e.g. Birds sold to trader @ Rs 180/kg") },
                    singleLine = false,
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmClose(notes.ifBlank { null }) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.testTag("confirm_close_batch_btn")
            ) {
                Text("Archive & Close Batch", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.BatchHistoryDialog
import com.example.ui.components.BatchSetupCard
import com.example.ui.components.CloseBatchDialog
import com.example.ui.components.DailyEntryForm
import com.example.ui.components.DashboardSummaryCard
import com.example.ui.components.ExportReportDialog
import com.example.ui.components.RegisterBookTable
import com.example.ui.theme.FarmBackground
import com.example.ui.theme.FarmGreenPrimary
import com.example.ui.theme.LiveBirdsGreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.PoultryViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: PoultryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                PoultryFarmApp(viewModel = viewModel)
            }
        }
    }
}

/**
 * Kept for test compatibility.
 */
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PoultryFarmApp(
    viewModel: PoultryViewModel,
    modifier: Modifier = Modifier
) {
    val activeBatch by viewModel.activeBatch.collectAsStateWithLifecycle()
    val allBatches by viewModel.allBatches.collectAsStateWithLifecycle()
    val dashboardMetrics by viewModel.dashboardMetrics.collectAsStateWithLifecycle()
    val registerRows by viewModel.registerBookRows.collectAsStateWithLifecycle()
    val setupFormState by viewModel.setupFormState.collectAsStateWithLifecycle()
    val entryFormState by viewModel.entryFormState.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    var showExportDialog by remember { mutableStateOf(false) }
    var showCloseBatchDialog by remember { mutableStateOf(false) }
    var showHistoryDialog by remember { mutableStateOf(false) }

    // Collect toast/snackbar events
    LaunchedEffect(viewModel) {
        viewModel.toastEvent.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        // Top Stylized Rooster / Poultry Farm Vector Logo
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFFFF8E7),
                            shadowElevation = 2.dp,
                            modifier = Modifier.size(42.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_rooster_logo),
                                contentDescription = "Poultry Farm Logo",
                                modifier = Modifier
                                    .padding(4.dp)
                                    .size(34.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            // Header Title: "Biraj Khan Poultry Farm Record"
                            Text(
                                text = "Biraj Khan Poultry Farm Record",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White,
                                maxLines = 1
                            )

                            // Sub-badge: "100% Offline | Lifelong Safe Storage (Room DB)"
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = Color(0xFF0F3813)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Security,
                                        contentDescription = null,
                                        tint = Color(0xFF81C784),
                                        modifier = Modifier.size(11.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "100% Offline | Lifelong Safe Storage (Room DB)",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFE8F5E9)
                                    )
                                }
                            }
                        }
                    }
                },
                actions = {
                    // Batches Archive / Switcher
                    IconButton(
                        onClick = { showHistoryDialog = true },
                        modifier = Modifier.testTag("flock_history_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "Flock History",
                            tint = Color.White
                        )
                    }

                    // Export / Share Report
                    if (activeBatch != null) {
                        IconButton(
                            onClick = { showExportDialog = true },
                            modifier = Modifier.testTag("appbar_export_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Export Report",
                                tint = Color.White
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = FarmGreenPrimary
                )
            )
        },
        containerColor = FarmBackground
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Batch Setup Card
            item {
                BatchSetupCard(
                    activeBatch = activeBatch,
                    formState = setupFormState,
                    onFlockNameChange = viewModel::updateSetupFlockName,
                    onInitialChicksChange = viewModel::updateSetupInitialChicks,
                    onInitialFeedBagsChange = viewModel::updateSetupInitialFeedBags,
                    onFeedBagSizeChange = viewModel::updateSetupFeedBagSizeKg,
                    onStartDateChange = viewModel::updateSetupStartDate,
                    onSubmit = viewModel::startNewBatch,
                    onCloseBatchClick = { showCloseBatchDialog = true }
                )
            }

            // If an active batch exists, render the Dashboard, Daily Form, and Register Book Table
            if (activeBatch != null) {
                // 2. Real-Time Auto Calculations Top Summary Dashboard
                item {
                    DashboardSummaryCard(
                        metrics = dashboardMetrics
                    )
                }

                // 3. Daily Log Entry Form
                item {
                    DailyEntryForm(
                        formState = entryFormState,
                        feedBagSizeKg = activeBatch?.feedBagWeightKg ?: 50.0,
                        onDateSelected = viewModel::onDateSelected,
                        onFeedBagsChanged = viewModel::onFeedBagsChanged,
                        onFeedKgChanged = viewModel::onFeedKgChanged,
                        onFeedReceivedChanged = viewModel::onFeedReceivedChanged,
                        onMortalityChanged = viewModel::onMortalityChanged,
                        onBodyWeightChanged = viewModel::onBodyWeightChanged,
                        onBodyWeightUnitChanged = viewModel::onBodyWeightUnitChanged,
                        onRemarksChanged = viewModel::onRemarksChanged,
                        onAppendRemarkTag = viewModel::appendRemarkTag,
                        onSaveClick = viewModel::saveDailyLog,
                        onCancelEditClick = {
                            val today = com.example.util.PoultryUtils.getTodayStartOfDay()
                            viewModel.onDateSelected(today)
                        }
                    )
                }

                // 4. Physical Company Logbook Table View (MOST IMPORTANT)
                item {
                    RegisterBookTable(
                        rows = registerRows,
                        onEditRow = viewModel::editRecordFromTable,
                        onDeleteLog = viewModel::deleteDailyRecord,
                        onExportReportClick = { showExportDialog = true }
                    )
                }

                // 5. Bottom Quick Actions (Export CSV / Report & Close Current Batch)
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp, bottom = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showExportDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("bottom_export_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export / Report", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { showCloseBatchDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("bottom_close_batch_btn"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Default.Archive, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Close Batch", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Export Dialog
    if (showExportDialog && activeBatch != null) {
        ExportReportDialog(
            batch = activeBatch!!,
            metrics = dashboardMetrics,
            rows = registerRows,
            onDismiss = { showExportDialog = false }
        )
    }

    // Close Batch Confirmation Dialog
    if (showCloseBatchDialog && activeBatch != null) {
        CloseBatchDialog(
            batch = activeBatch!!,
            metrics = dashboardMetrics,
            onDismiss = { showCloseBatchDialog = false },
            onConfirmClose = { notes ->
                showCloseBatchDialog = false
                viewModel.closeActiveBatch(notes)
            }
        )
    }

    // Batch History Dialog
    if (showHistoryDialog) {
        BatchHistoryDialog(
            batches = allBatches,
            activeBatchId = activeBatch?.id,
            onSelectBatch = { batch ->
                viewModel.reactivateBatch(batch)
            },
            onDismiss = { showHistoryDialog = false }
        )
    }
}

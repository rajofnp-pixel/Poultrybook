package com.example

import com.example.data.model.DailyLog
import com.example.data.model.FlockBatch
import com.example.util.PoultryUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testAgeCalculation() {
        val startDate = PoultryUtils.getStartOfDay(1700000000000L)
        val day1 = startDate
        val day2 = startDate + (24L * 60 * 60 * 1000)
        val day7 = startDate + (6L * 24 * 60 * 60 * 1000)

        assertEquals(1, PoultryUtils.calculateAgeDays(startDate, day1))
        assertEquals(2, PoultryUtils.calculateAgeDays(startDate, day2))
        assertEquals(7, PoultryUtils.calculateAgeDays(startDate, day7))
    }

    @Test
    fun testRegisterBookRunningBalances() {
        val batch = FlockBatch(
            id = 1,
            flockName = "Test Flock #1",
            initialChicks = 1000,
            initialFeedBags = 40.0,
            feedBagWeightKg = 50.0,
            startDate = 1700000000000L
        )

        val logs = listOf(
            DailyLog(
                id = 1,
                batchId = 1,
                logDate = batch.startDate,
                ageDays = 1,
                feedConsumedBags = 1.0,
                feedConsumedKg = 50.0,
                feedReceivedBags = 0.0,
                mortality = 2,
                bodyWeightGrams = 45.0,
                remarks = "Chicks arrived, alert"
            ),
            DailyLog(
                id = 2,
                batchId = 1,
                logDate = batch.startDate + (24L * 60 * 60 * 1000),
                ageDays = 2,
                feedConsumedBags = 1.5,
                feedConsumedKg = 75.0,
                feedReceivedBags = 10.0,
                mortality = 3,
                bodyWeightGrams = null,
                remarks = "New feed stock arrived"
            )
        )

        val rows = PoultryUtils.computeRegisterBookRows(batch, logs)
        assertEquals(2, rows.size)

        // Day 1:
        // Live birds = 1000 - 2 = 998
        // Remaining feed = 40 - 1 = 39 bags
        assertEquals(998, rows[0].runningLiveBirds)
        assertEquals(39.0, rows[0].remainingFeedBags, 0.001)

        // Day 2:
        // Cumulative mortality = 2 + 3 = 5
        // Live birds = 1000 - 5 = 995
        // Cumulative received = 10 -> Total stock = 50
        // Cumulative consumed = 1.0 + 1.5 = 2.5 -> Remaining = 47.5 bags
        assertEquals(995, rows[1].runningLiveBirds)
        assertEquals(47.5, rows[1].remainingFeedBags, 0.001)

        // CSV export
        val csv = PoultryUtils.generateCsv(batch, rows)
        assertTrue(csv.contains("Biraj Khan Poultry Farm Record", ignoreCase = true))
        assertTrue(csv.contains("Day 1"))
        assertTrue(csv.contains("Day 2"))
        assertTrue(csv.contains("995"))
    }
}

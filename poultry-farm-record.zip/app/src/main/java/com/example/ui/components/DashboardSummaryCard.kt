package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.Egg
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FeedAmber
import com.example.ui.theme.LiveBirdsGreen
import com.example.ui.theme.MetricBlue
import com.example.ui.theme.MortalityRed
import com.example.ui.viewmodel.DashboardMetrics
import com.example.util.PoultryUtils

@Composable
fun DashboardSummaryCard(
    metrics: DashboardMetrics,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("dashboard_summary_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Dashboard Title Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Real-Time Flock Summary",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = LiveBirdsGreen.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "LIVE ACTIVE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = LiveBirdsGreen,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 2x2 Grid of Key Poultry Metrics
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Metric 1: Current Live Birds
                MetricTile(
                    title = "Live Stock Birds",
                    value = "${metrics.currentLiveBirds}",
                    subValue = "of ${metrics.initialChicks} initial chicks",
                    icon = Icons.Default.Egg,
                    accentColor = LiveBirdsGreen,
                    modifier = Modifier.weight(1f)
                )

                // Metric 2: Mortality Rate (%)
                MetricTile(
                    title = "Mortality Rate",
                    value = "${PoultryUtils.formatNumber(metrics.mortalityRate)}%",
                    subValue = "${metrics.cumulativeMortality} dead cumulative",
                    icon = Icons.Default.CrisisAlert,
                    accentColor = if (metrics.mortalityRate > 5.0) MortalityRed else Color(0xFFD32F2F),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Metric 3: Remaining Feed Stock
                MetricTile(
                    title = "Remaining Feed",
                    value = "${PoultryUtils.formatNumber(metrics.remainingFeedStockBags)} Bags",
                    subValue = "${PoultryUtils.formatNumber(metrics.remainingFeedStockKg)} kg available",
                    icon = Icons.Default.Inventory2,
                    accentColor = FeedAmber,
                    modifier = Modifier.weight(1f)
                )

                // Metric 4: Total Feed Consumed
                MetricTile(
                    title = "Feed Consumed",
                    value = "${PoultryUtils.formatNumber(metrics.totalFeedConsumedBags)} Bags",
                    subValue = "${PoultryUtils.formatNumber(metrics.totalFeedConsumedKg)} kg total eaten",
                    icon = Icons.Default.Restaurant,
                    accentColor = MetricBlue,
                    modifier = Modifier.weight(1f)
                )
            }

            // Subtle Feed Stock Bar
            val totalFeedEver = (metrics.remainingFeedStockBags + metrics.totalFeedConsumedBags)
            val feedProgress = if (totalFeedEver > 0) {
                (metrics.remainingFeedStockBags / totalFeedEver).toFloat().coerceIn(0f, 1f)
            } else 1f

            Spacer(modifier = Modifier.height(14.dp))
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "Feed Stock Remaining Capacity",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "${(feedProgress * 100).toInt()}% in barn",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = FeedAmber
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { feedProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = FeedAmber,
                    trackColor = FeedAmber.copy(alpha = 0.15f)
                )
            }
        }
    }
}

@Composable
private fun MetricTile(
    title: String,
    value: String,
    subValue: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = accentColor.copy(alpha = 0.08f)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = accentColor
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subValue,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

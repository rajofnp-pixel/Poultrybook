package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DailyLog
import com.example.data.model.FlockBatch
import kotlinx.coroutines.flow.Flow

@Dao
interface PoultryDao {

    // --- Batch Operations ---
    @Query("SELECT * FROM flock_batches WHERE isActive = 1 ORDER BY id DESC LIMIT 1")
    fun getActiveBatch(): Flow<FlockBatch?>

    @Query("SELECT * FROM flock_batches ORDER BY id DESC")
    fun getAllBatches(): Flow<List<FlockBatch>>

    @Query("SELECT * FROM flock_batches WHERE id = :batchId LIMIT 1")
    fun getBatchById(batchId: Long): Flow<FlockBatch?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBatch(batch: FlockBatch): Long

    @Update
    suspend fun updateBatch(batch: FlockBatch)

    @Delete
    suspend fun deleteBatch(batch: FlockBatch)

    // --- Daily Log Operations ---
    @Query("SELECT * FROM daily_logs WHERE batchId = :batchId ORDER BY logDate ASC")
    fun getLogsForBatch(batchId: Long): Flow<List<DailyLog>>

    @Query("SELECT * FROM daily_logs WHERE batchId = :batchId AND logDate = :logDate LIMIT 1")
    suspend fun getLogByDate(batchId: Long, logDate: Long): DailyLog?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateLog(log: DailyLog): Long

    @Update
    suspend fun updateLog(log: DailyLog)

    @Delete
    suspend fun deleteLog(log: DailyLog)

    @Query("DELETE FROM daily_logs WHERE id = :logId")
    suspend fun deleteLogById(logId: Long)
}

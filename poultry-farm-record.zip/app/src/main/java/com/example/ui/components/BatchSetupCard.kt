package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Egg
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SelectableDates
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FlockBatch
import com.example.ui.theme.FarmGreenPrimary
import com.example.ui.viewmodel.BatchSetupFormState
import com.example.util.PoultryUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BatchSetupCard(
    activeBatch: FlockBatch?,
    formState: BatchSetupFormState,
    onFlockNameChange: (String) -> Unit,
    onInitialChicksChange: (String) -> Unit,
    onInitialFeedBagsChange: (String) -> Unit,
    onFeedBagSizeChange: (String) -> Unit,
    onStartDateChange: (Long) -> Unit,
    onSubmit: () -> Unit,
    onCloseBatchClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // If there is an active batch, card is collapsible. If no active batch, always open.
    var isExpanded by remember(activeBatch == null) { mutableStateOf(activeBatch == null) }
    var showDatePicker by remember { mutableStateOf(false) }

    // DatePicker state locked against future dates
    val todayMidnight = PoultryUtils.getTodayStartOfDay()
    val datePickerState = rememberDatePickerState(
        initialSelectedDateMillis = formState.startDate,
        selectableDates = object : SelectableDates {
            override fun isSelectableDate(utcTimeMillis: Long): Boolean {
                // STRICT RULE: Future dates are disabled/locked
                return utcTimeMillis <= System.currentTimeMillis()
            }
        }
    )

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { selected ->
                            onStartDateChange(selected)
                        }
                        showDatePicker = false
                    }
                ) {
                    Text("Select Date", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(
                state = datePickerState,
                title = {
                    Text(
                        "Select Batch Placement Date",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                },
                headline = {
                    Text(
                        "Future dates are strictly locked",
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            )
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("batch_setup_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Card Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (activeBatch != null) {
                            isExpanded = !isExpanded
                        }
                    },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = FarmGreenPrimary.copy(alpha = 0.12f),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Egg,
                            contentDescription = "Flock Setup",
                            tint = FarmGreenPrimary,
                            modifier = Modifier
                                .padding(8.dp)
                                .size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (activeBatch != null) activeBatch.flockName else "Batch Setup & Placement",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (activeBatch != null) {
                                "Placed: ${PoultryUtils.formatDate(activeBatch.startDate)} | ${activeBatch.initialChicks} birds"
                            } else {
                                "Enter initial birds & feed to start daily ledger"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (activeBatch != null) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isExpanded) "Collapse" else "Expand",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Quick action buttons when collapsed
            if (activeBatch != null && !isExpanded) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Initial Stock:",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                "${PoultryUtils.formatNumber(activeBatch.initialFeedBags)} Bags (${activeBatch.feedBagWeightKg.toInt()} kg/bag)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = onCloseBatchClick,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("close_batch_quick_btn")
                    ) {
                        Text("Close Batch", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            // Expanded Form
            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Flock Batch Name
                    OutlinedTextField(
                        value = formState.flockName,
                        onValueChange = onFlockNameChange,
                        label = { Text("Flock Batch Name") },
                        placeholder = { Text("e.g. Broiler Batch #1") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("setup_flock_name_input")
                    )

                    // Initial Chicks and Initial Feed Bags in a 2-column Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = formState.initialChicks,
                            onValueChange = onInitialChicksChange,
                            label = { Text("Total Chicks Placed") },
                            placeholder = { Text("1000") },
                            leadingIcon = {
                                Icon(Icons.Default.Egg, contentDescription = null, modifier = Modifier.size(20.dp))
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("setup_initial_chicks_input")
                        )

                        OutlinedTextField(
                            value = formState.initialFeedBags,
                            onValueChange = onInitialFeedBagsChange,
                            label = { Text("Initial Feed Bags") },
                            placeholder = { Text("40") },
                            leadingIcon = {
                                Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(20.dp))
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("setup_initial_bags_input")
                        )
                    }

                    // Feed Bag Size and Start Date
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = formState.feedBagSizeKg,
                            onValueChange = onFeedBagSizeChange,
                            label = { Text("Bag Size (KG)") },
                            placeholder = { Text("50") },
                            leadingIcon = {
                                Icon(Icons.Default.Scale, contentDescription = null, modifier = Modifier.size(20.dp))
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("setup_bag_size_input")
                        )

                        // Start Date Picker Field
                        OutlinedTextField(
                            value = PoultryUtils.formatDate(formState.startDate),
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Batch Start Date") },
                            trailingIcon = {
                                Icon(
                                    Icons.Default.CalendarToday,
                                    contentDescription = "Pick Start Date",
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clickable { showDatePicker = true }
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .clickable { showDatePicker = true }
                                .testTag("setup_start_date_input")
                        )
                    }

                    if (formState.error != null) {
                        Text(
                            text = formState.error,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    // Button
                    Button(
                        onClick = onSubmit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_and_start_batch_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (activeBatch == null) "Save & Start Batch" else "Save & Start New Batch",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

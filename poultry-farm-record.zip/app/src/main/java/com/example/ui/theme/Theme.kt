package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = DarkFarmGreenPrimary,
    onPrimary = Color(0xFF00390E),
    primaryContainer = Color(0xFF005318),
    onPrimaryContainer = Color(0xFF9CF69E),
    secondary = DarkFarmAmberSecondary,
    onSecondary = Color(0xFF482000),
    secondaryContainer = Color(0xFF673000),
    onSecondaryContainer = Color(0xFFFFDBC9),
    background = DarkFarmBackground,
    surface = DarkFarmSurface,
    surfaceVariant = DarkFarmSurfaceVariant,
    onBackground = Color(0xFFE2E3DE),
    onSurface = Color(0xFFE2E3DE)
)

private val LightColorScheme = lightColorScheme(
    primary = FarmGreenPrimary,
    onPrimary = FarmGreenOnPrimary,
    primaryContainer = FarmGreenContainer,
    onPrimaryContainer = FarmGreenOnContainer,
    secondary = FarmAmberSecondary,
    onSecondary = FarmAmberOnSecondary,
    secondaryContainer = FarmAmberContainer,
    onSecondaryContainer = FarmAmberOnContainer,
    tertiary = FarmTertiary,
    onTertiary = FarmOnTertiary,
    tertiaryContainer = FarmTertiaryContainer,
    onTertiaryContainer = FarmOnTertiaryContainer,
    background = FarmBackground,
    surface = FarmSurface,
    surfaceVariant = FarmSurfaceVariant,
    onBackground = FarmOnSurface,
    onSurface = FarmOnSurface,
    onSurfaceVariant = FarmOnSurfaceVariant,
    outline = FarmOutline,
    outlineVariant = FarmOutlineVariant
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Preserve custom farm branding colors
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

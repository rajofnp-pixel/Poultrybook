package com.example.data.repository

import com.example.data.dao.PoultryDao
import com.example.data.model.DailyLog
import com.example.data.model.FlockBatch
import kotlinx.coroutines.flow.Flow

class PoultryRepository(private val poultryDao: PoultryDao) {

    val activeBatch: Flow<FlockBatch?> = poultryDao.getActiveBatch()
    val allBatches: Flow<List<FlockBatch>> = poultryDao.getAllBatches()

    fun getLogsForBatch(batchId: Long): Flow<List<DailyLog>> {
        return poultryDao.getLogsForBatch(batchId)
    }

    suspend fun getLogByDate(batchId: Long, logDate: Long): DailyLog? {
        return poultryDao.getLogByDate(batchId, logDate)
    }

    suspend fun createBatch(
        flockName: String,
        initialChicks: Int,
        initialFeedBags: Double,
        feedBagWeightKg: Double,
        startDate: Long
    ): Long {
        val batch = FlockBatch(
            flockName = flockName,
            initialChicks = initialChicks,
            initialFeedBags = initialFeedBags,
            feedBagWeightKg = feedBagWeightKg,
            startDate = startDate,
            isActive = true
        )
        return poultryDao.insertBatch(batch)
    }

    suspend fun updateBatch(batch: FlockBatch) {
        poultryDao.updateBatch(batch)
    }

    suspend fun closeBatch(batchId: Long, closingNotes: String?) {
        // Find batch and set isActive = false
        // Room update can be done on the object
    }

    suspend fun saveDailyLog(log: DailyLog): Long {
        return poultryDao.insertOrUpdateLog(log)
    }

    suspend fun deleteDailyLog(log: DailyLog) {
        poultryDao.deleteLog(log)
    }

    suspend fun deleteDailyLogById(logId: Long) {
        poultryDao.deleteLogById(logId)
    }
}

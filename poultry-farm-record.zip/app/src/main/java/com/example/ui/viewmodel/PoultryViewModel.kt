package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.PoultryDatabase
import com.example.data.model.DailyLog
import com.example.data.model.FlockBatch
import com.example.data.repository.PoultryRepository
import com.example.util.PoultryUtils
import com.example.util.RegisterBookRow
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DashboardMetrics(
    val initialChicks: Int = 0,
    val currentLiveBirds: Int = 0,
    val cumulativeMortality: Int = 0,
    val mortalityRate: Double = 0.0,
    val remainingFeedStockBags: Double = 0.0,
    val remainingFeedStockKg: Double = 0.0,
    val totalFeedConsumedBags: Double = 0.0,
    val totalFeedConsumedKg: Double = 0.0,
    val totalFeedReceivedBags: Double = 0.0
)

data class BatchSetupFormState(
    val flockName: String = "Flock Batch #1",
    val initialChicks: String = "1000",
    val initialFeedBags: String = "40",
    val feedBagSizeKg: String = "50",
    val startDate: Long = PoultryUtils.getTodayStartOfDay(),
    val error: String? = null
)

data class DailyEntryFormState(
    val logDate: Long = PoultryUtils.getTodayStartOfDay(),
    val ageDays: Int = 1,
    val feedConsumedBags: String = "",
    val feedConsumedKg: String = "",
    val newFeedReceivedBags: String = "",
    val dailyMortality: String = "",
    val bodyWeightValue: String = "",
    val bodyWeightUnit: String = "g", // "g" or "kg"
    val remarks: String = "",
    val editingLogId: Long? = null,
    val isSaving: Boolean = false,
    val error: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class PoultryViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PoultryRepository

    init {
        val db = PoultryDatabase.getDatabase(application)
        repository = PoultryRepository(db.poultryDao())
    }

    // Active batch flow
    val activeBatch: StateFlow<FlockBatch?> = repository.activeBatch
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val allBatches: StateFlow<List<FlockBatch>> = repository.allBatches
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Daily logs for current active batch
    val dailyLogs: StateFlow<List<DailyLog>> = activeBatch
        .flatMapLatest { batch ->
            if (batch != null) {
                repository.getLogsForBatch(batch.id)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Combined Dashboard Metrics
    val dashboardMetrics: StateFlow<DashboardMetrics> = combine(
        activeBatch,
        dailyLogs
    ) { batch, logs ->
        if (batch == null) {
            DashboardMetrics()
        } else {
            var cumMortality = 0
            var cumConsumedBags = 0.0
            var cumConsumedKg = 0.0
            var cumReceivedBags = 0.0

            for (log in logs) {
                cumMortality += log.mortality
                cumConsumedBags += log.feedConsumedBags
                cumConsumedKg += log.feedConsumedKg
                cumReceivedBags += log.feedReceivedBags
            }

            val liveBirds = maxOf(0, batch.initialChicks - cumMortality)
            val mortRate = if (batch.initialChicks > 0) {
                (cumMortality.toDouble() / batch.initialChicks.toDouble()) * 100.0
            } else {
                0.0
            }

            val totalStockBags = batch.initialFeedBags + cumReceivedBags
            val remainingBags = maxOf(0.0, totalStockBags - cumConsumedBags)
            val remainingKg = remainingBags * batch.feedBagWeightKg

            DashboardMetrics(
                initialChicks = batch.initialChicks,
                currentLiveBirds = liveBirds,
                cumulativeMortality = cumMortality,
                mortalityRate = mortRate,
                remainingFeedStockBags = remainingBags,
                remainingFeedStockKg = remainingKg,
                totalFeedConsumedBags = cumConsumedBags,
                totalFeedConsumedKg = cumConsumedKg,
                totalFeedReceivedBags = cumReceivedBags
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardMetrics()
    )

    // Register Book Rows
    val registerBookRows: StateFlow<List<RegisterBookRow>> = combine(
        activeBatch,
        dailyLogs
    ) { batch, logs ->
        if (batch == null || logs.isEmpty()) {
            emptyList()
        } else {
            PoultryUtils.computeRegisterBookRows(batch, logs)
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Setup Form State
    private val _setupFormState = MutableStateFlow(BatchSetupFormState())
    val setupFormState: StateFlow<BatchSetupFormState> = _setupFormState.asStateFlow()

    // Daily Entry Form State
    private val _entryFormState = MutableStateFlow(DailyEntryFormState())
    val entryFormState: StateFlow<DailyEntryFormState> = _entryFormState.asStateFlow()

    // Transient UI Events (Snackbar / Toast notifications)
    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    init {
        // Automatically sync entry form date and age when active batch changes
        viewModelScope.launch {
            activeBatch.collect { batch ->
                if (batch != null) {
                    val today = PoultryUtils.getTodayStartOfDay()
                    val age = PoultryUtils.calculateAgeDays(batch.startDate, today)
                    _entryFormState.update {
                        it.copy(
                            logDate = today,
                            ageDays = age
                        )
                    }
                    // If entry exists for today, load it for easy editing
                    loadExistingLogForDate(batch.id, today)
                }
            }
        }
    }

    // --- Batch Setup Actions ---
    fun updateSetupFlockName(name: String) {
        _setupFormState.update { it.copy(flockName = name, error = null) }
    }

    fun updateSetupInitialChicks(chicks: String) {
        _setupFormState.update { it.copy(initialChicks = chicks, error = null) }
    }

    fun updateSetupInitialFeedBags(bags: String) {
        _setupFormState.update { it.copy(initialFeedBags = bags, error = null) }
    }

    fun updateSetupFeedBagSizeKg(kg: String) {
        _setupFormState.update { it.copy(feedBagSizeKg = kg, error = null) }
    }

    fun updateSetupStartDate(dateMillis: Long) {
        // Enforce lock against future date
        val todayMidnight = PoultryUtils.getTodayStartOfDay()
        val normalized = PoultryUtils.getStartOfDay(dateMillis)
        if (normalized > todayMidnight) {
            _setupFormState.update { it.copy(error = "Batch start date cannot be in the future!") }
            return
        }
        _setupFormState.update { it.copy(startDate = normalized, error = null) }
    }

    fun startNewBatch() {
        val state = _setupFormState.value
        val chicks = state.initialChicks.trim().toIntOrNull()
        if (chicks == null || chicks <= 0) {
            _setupFormState.update { it.copy(error = "Please enter valid number of chicks (e.g. 1000)") }
            return
        }
        val feedBags = state.initialFeedBags.trim().toDoubleOrNull()
        if (feedBags == null || feedBags < 0) {
            _setupFormState.update { it.copy(error = "Please enter valid initial feed bags (e.g. 40)") }
            return
        }
        val bagSize = state.feedBagSizeKg.trim().toDoubleOrNull() ?: 50.0

        viewModelScope.launch {
            try {
                // If there's an active batch, deactivate it
                val current = activeBatch.value
                if (current != null) {
                    repository.updateBatch(
                        current.copy(
                            isActive = false,
                            closedDate = System.currentTimeMillis()
                        )
                    )
                }

                val batchId = repository.createBatch(
                    flockName = state.flockName.ifBlank { "Flock Batch #${(allBatches.value.size + 1)}" },
                    initialChicks = chicks,
                    initialFeedBags = feedBags,
                    feedBagWeightKg = bagSize,
                    startDate = state.startDate
                )

                _toastEvent.emit("Batch created successfully! Ready for Day 1 entries.")
                // Reset daily form
                val today = PoultryUtils.getTodayStartOfDay()
                val age = PoultryUtils.calculateAgeDays(state.startDate, today)
                _entryFormState.value = DailyEntryFormState(
                    logDate = today,
                    ageDays = age
                )
            } catch (e: Exception) {
                _setupFormState.update { it.copy(error = e.localizedMessage ?: "Failed to save batch") }
            }
        }
    }

    fun closeActiveBatch(closingNotes: String? = null) {
        val batch = activeBatch.value ?: return
        viewModelScope.launch {
            repository.updateBatch(
                batch.copy(
                    isActive = false,
                    closedDate = System.currentTimeMillis(),
                    closingNotes = closingNotes
                )
            )
            _toastEvent.emit("Batch closed and safely archived. You can start a new flock anytime.")
        }
    }

    fun reactivateBatch(batch: FlockBatch) {
        viewModelScope.launch {
            val current = activeBatch.value
            if (current != null && current.id != batch.id) {
                repository.updateBatch(current.copy(isActive = false))
            }
            repository.updateBatch(batch.copy(isActive = true))
            _toastEvent.emit("Switched to ${batch.flockName}")
        }
    }

    // --- Daily Entry Form Actions ---

    fun onDateSelected(dateMillis: Long) {
        val today = PoultryUtils.getTodayStartOfDay()
        val normalized = PoultryUtils.getStartOfDay(dateMillis)
        if (normalized > today) {
            viewModelScope.launch { _toastEvent.emit("Future dates are locked and cannot be selected.") }
            return
        }

        val batch = activeBatch.value ?: return
        val age = PoultryUtils.calculateAgeDays(batch.startDate, normalized)

        _entryFormState.update {
            it.copy(
                logDate = normalized,
                ageDays = age,
                error = null
            )
        }

        // Auto prefill if entry already exists for this date!
        loadExistingLogForDate(batch.id, normalized)
    }

    private fun loadExistingLogForDate(batchId: Long, dateMillis: Long) {
        viewModelScope.launch {
            val existing = repository.getLogByDate(batchId, dateMillis)
            val batch = activeBatch.value
            val bagSize = batch?.feedBagWeightKg ?: 50.0

            if (existing != null) {
                val weight = existing.bodyWeightGrams
                val weightStr = if (weight != null && weight > 0) {
                    if (weight >= 1000) PoultryUtils.formatNumber(weight / 1000.0) else PoultryUtils.formatNumber(weight)
                } else ""
                val weightUnit = if (weight != null && weight >= 1000) "kg" else "g"

                _entryFormState.update {
                    it.copy(
                        editingLogId = existing.id,
                        feedConsumedBags = if (existing.feedConsumedBags > 0) PoultryUtils.formatNumber(existing.feedConsumedBags) else "",
                        feedConsumedKg = if (existing.feedConsumedKg > 0) PoultryUtils.formatNumber(existing.feedConsumedKg) else "",
                        newFeedReceivedBags = if (existing.feedReceivedBags > 0) PoultryUtils.formatNumber(existing.feedReceivedBags) else "",
                        dailyMortality = if (existing.mortality > 0) existing.mortality.toString() else "0",
                        bodyWeightValue = weightStr,
                        bodyWeightUnit = weightUnit,
                        remarks = existing.remarks
                    )
                }
            } else {
                // Clear fields for new entry on this date
                _entryFormState.update {
                    it.copy(
                        editingLogId = null,
                        feedConsumedBags = "",
                        feedConsumedKg = "",
                        newFeedReceivedBags = "",
                        dailyMortality = "0",
                        bodyWeightValue = "",
                        remarks = ""
                    )
                }
            }
        }
    }

    fun onFeedBagsChanged(bagsStr: String) {
        val batch = activeBatch.value
        val bagSize = batch?.feedBagWeightKg ?: 50.0
        val bags = bagsStr.toDoubleOrNull()
        val calculatedKg = if (bags != null && bags >= 0) PoultryUtils.formatNumber(bags * bagSize) else ""

        _entryFormState.update {
            it.copy(
                feedConsumedBags = bagsStr,
                feedConsumedKg = calculatedKg,
                error = null
            )
        }
    }

    fun onFeedKgChanged(kgStr: String) {
        val batch = activeBatch.value
        val bagSize = batch?.feedBagWeightKg ?: 50.0
        val kg = kgStr.toDoubleOrNull()
        val calculatedBags = if (kg != null && kg >= 0 && bagSize > 0) PoultryUtils.formatNumber(kg / bagSize) else ""

        _entryFormState.update {
            it.copy(
                feedConsumedKg = kgStr,
                feedConsumedBags = calculatedBags,
                error = null
            )
        }
    }

    fun onFeedReceivedChanged(bagsStr: String) {
        _entryFormState.update { it.copy(newFeedReceivedBags = bagsStr, error = null) }
    }

    fun onMortalityChanged(mortStr: String) {
        _entryFormState.update { it.copy(dailyMortality = mortStr, error = null) }
    }

    fun onBodyWeightChanged(weightStr: String) {
        _entryFormState.update { it.copy(bodyWeightValue = weightStr, error = null) }
    }

    fun onBodyWeightUnitChanged(unit: String) {
        _entryFormState.update { it.copy(bodyWeightUnit = unit) }
    }

    fun onRemarksChanged(remarksStr: String) {
        _entryFormState.update { it.copy(remarks = remarksStr) }
    }

    fun appendRemarkTag(tag: String) {
        val current = _entryFormState.value.remarks.trim()
        val newText = if (current.isBlank()) tag else if (!current.contains(tag)) "$current | $tag" else current
        _entryFormState.update { it.copy(remarks = newText) }
    }

    fun saveDailyLog() {
        val batch = activeBatch.value
        if (batch == null) {
            _entryFormState.update { it.copy(error = "No active batch found. Please start a batch first.") }
            return
        }

        val state = _entryFormState.value

        val consumedBags = state.feedConsumedBags.trim().toDoubleOrNull() ?: 0.0
        val consumedKg = state.feedConsumedKg.trim().toDoubleOrNull() ?: (consumedBags * batch.feedBagWeightKg)
        val receivedBags = state.newFeedReceivedBags.trim().toDoubleOrNull() ?: 0.0
        val mortality = state.dailyMortality.trim().toIntOrNull() ?: 0

        if (mortality < 0) {
            _entryFormState.update { it.copy(error = "Mortality cannot be negative.") }
            return
        }

        // Convert body weight to grams for uniform storage
        val weightVal = state.bodyWeightValue.trim().toDoubleOrNull()
        val bodyWeightGrams: Double? = if (weightVal != null && weightVal > 0) {
            if (state.bodyWeightUnit == "kg") weightVal * 1000.0 else weightVal
        } else null

        viewModelScope.launch {
            _entryFormState.update { it.copy(isSaving = true, error = null) }
            try {
                val logToSave = DailyLog(
                    id = state.editingLogId ?: 0,
                    batchId = batch.id,
                    logDate = state.logDate,
                    ageDays = state.ageDays,
                    feedConsumedBags = consumedBags,
                    feedConsumedKg = consumedKg,
                    feedReceivedBags = receivedBags,
                    mortality = mortality,
                    bodyWeightGrams = bodyWeightGrams,
                    remarks = state.remarks.trim()
                )

                repository.saveDailyLog(logToSave)

                _toastEvent.emit("Day ${state.ageDays} record saved successfully to Register Book!")
                // Reset or keep date ready
                _entryFormState.update {
                    it.copy(
                        isSaving = false,
                        editingLogId = null,
                        feedConsumedBags = "",
                        feedConsumedKg = "",
                        newFeedReceivedBags = "",
                        dailyMortality = "0",
                        bodyWeightValue = "",
                        remarks = "",
                        error = null
                    )
                }
            } catch (e: Exception) {
                _entryFormState.update { it.copy(isSaving = false, error = e.localizedMessage ?: "Failed to save record.") }
            }
        }
    }

    fun editRecordFromTable(row: RegisterBookRow) {
        val log = row.log
        val batch = activeBatch.value
        val weight = log.bodyWeightGrams
        val weightStr = if (weight != null && weight > 0) {
            if (weight >= 1000) PoultryUtils.formatNumber(weight / 1000.0) else PoultryUtils.formatNumber(weight)
        } else ""
        val weightUnit = if (weight != null && weight >= 1000) "kg" else "g"

        _entryFormState.update {
            it.copy(
                editingLogId = log.id,
                logDate = log.logDate,
                ageDays = log.ageDays,
                feedConsumedBags = if (log.feedConsumedBags > 0) PoultryUtils.formatNumber(log.feedConsumedBags) else "",
                feedConsumedKg = if (log.feedConsumedKg > 0) PoultryUtils.formatNumber(log.feedConsumedKg) else "",
                newFeedReceivedBags = if (log.feedReceivedBags > 0) PoultryUtils.formatNumber(log.feedReceivedBags) else "",
                dailyMortality = log.mortality.toString(),
                bodyWeightValue = weightStr,
                bodyWeightUnit = weightUnit,
                remarks = log.remarks,
                error = null
            )
        }
        viewModelScope.launch {
            _toastEvent.emit("Loaded Day ${log.ageDays} into entry form for editing.")
        }
    }

    fun deleteDailyRecord(log: DailyLog) {
        viewModelScope.launch {
            repository.deleteDailyLog(log)
            _toastEvent.emit("Deleted record for Day ${log.ageDays}.")
        }
    }
}

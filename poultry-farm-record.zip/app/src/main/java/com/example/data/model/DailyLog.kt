package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Represents a single day's log entry in the Poultry Farm Register Book.
 */
@Entity(
    tableName = "daily_logs",
    foreignKeys = [
        ForeignKey(
            entity = FlockBatch::class,
            parentColumns = ["id"],
            childColumns = ["batchId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["batchId"]),
        Index(value = ["batchId", "logDate"], unique = true)
    ]
)
data class DailyLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val batchId: Long,
    val logDate: Long, // Epoch timestamp at midnight
    val ageDays: Int,  // Calculated elapsed day from start date (Day 1, Day 2, etc.)
    val feedConsumedBags: Double,
    val feedConsumedKg: Double,
    val feedReceivedBags: Double = 0.0,
    val mortality: Int = 0,
    val bodyWeightGrams: Double? = null,
    val remarks: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

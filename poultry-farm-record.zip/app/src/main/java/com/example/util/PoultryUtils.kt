package com.example.util

import com.example.data.model.DailyLog
import com.example.data.model.FlockBatch
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object PoultryUtils {

    private val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private val dateShortFormat = SimpleDateFormat("dd/MM/yy", Locale.getDefault())
    private val numberFormat = DecimalFormat("#,##0.##")

    /**
     * Normalizes a timestamp to the beginning of the day (00:00:00.000).
     */
    fun getStartOfDay(epochMillis: Long): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = epochMillis
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    /**
     * Gets today's midnight timestamp.
     */
    fun getTodayStartOfDay(): Long {
        return getStartOfDay(System.currentTimeMillis())
    }

    /**
     * Format timestamp to readable string (e.g. "16 Sep 2026").
     */
    fun formatDate(epochMillis: Long): String {
        return dateFormat.format(Date(epochMillis))
    }

    /**
     * Format timestamp to compact string (e.g. "16/09/26").
     */
    fun formatDateShort(epochMillis: Long): String {
        return dateShortFormat.format(Date(epochMillis))
    }

    /**
     * Calculate elapsed days (Day 1 for start date, Day 2 for next day, etc.).
     */
    fun calculateAgeDays(batchStartDate: Long, targetDate: Long): Int {
        val startMidnight = getStartOfDay(batchStartDate)
        val targetMidnight = getStartOfDay(targetDate)
        val diffMillis = targetMidnight - startMidnight
        val diffDays = (diffMillis / (24L * 60 * 60 * 1000)).toInt()
        return maxOf(1, diffDays + 1)
    }

    /**
     * Pretty print decimal numbers, e.g. 1.5 or 40.
     */
    fun formatNumber(value: Double): String {
        return numberFormat.format(value)
    }

    /**
     * Builds data structures for the physical register book ledger with running balances.
     */
    fun computeRegisterBookRows(
        batch: FlockBatch,
        sortedLogs: List<DailyLog>
    ): List<RegisterBookRow> {
        var cumulativeMortality = 0
        var cumulativeConsumedBags = 0.0
        var cumulativeReceivedBags = 0.0

        return sortedLogs.map { log ->
            cumulativeMortality += log.mortality
            cumulativeConsumedBags += log.feedConsumedBags
            cumulativeReceivedBags += log.feedReceivedBags

            val runningLiveBirds = maxOf(0, batch.initialChicks - cumulativeMortality)
            val totalFeedStock = batch.initialFeedBags + cumulativeReceivedBags
            val remainingBags = maxOf(0.0, totalFeedStock - cumulativeConsumedBags)
            val remainingKg = remainingBags * batch.feedBagWeightKg

            val feedConsumedStr = "${formatNumber(log.feedConsumedBags)} bags (${formatNumber(log.feedConsumedKg)} kg)"
            val bodyWeightStr = if (log.bodyWeightGrams != null && log.bodyWeightGrams > 0) {
                if (log.bodyWeightGrams >= 1000) {
                    "${formatNumber(log.bodyWeightGrams / 1000.0)} kg"
                } else {
                    "${formatNumber(log.bodyWeightGrams)} g"
                }
            } else {
                "—"
            }

            RegisterBookRow(
                log = log,
                dayNumber = log.ageDays,
                formattedDate = formatDate(log.logDate),
                feedConsumedDisplay = feedConsumedStr,
                remainingFeedBags = remainingBags,
                remainingFeedKg = remainingKg,
                remainingFeedDisplay = "${formatNumber(remainingBags)} bags",
                dailyMortality = log.mortality,
                runningLiveBirds = runningLiveBirds,
                bodyWeightDisplay = bodyWeightStr,
                remarks = if (log.remarks.isBlank()) "—" else log.remarks
            )
        }
    }

    /**
     * Generates a CSV export of the physical logbook for Excel or Google Sheets.
     */
    fun generateCsv(batch: FlockBatch, rows: List<RegisterBookRow>): String {
        val sb = StringBuilder()
        sb.append("BIRAJ KHAN POULTRY FARM RECORD - REGISTER BOOK EXPORT\n")
        sb.append("Flock:,\"${batch.flockName}\"\n")
        sb.append("Batch Start Date:,\"${formatDate(batch.startDate)}\"\n")
        sb.append("Initial Birds Placed:,\"${batch.initialChicks}\"\n")
        sb.append("Initial Feed Stock:,\"${formatNumber(batch.initialFeedBags)} bags (${batch.feedBagWeightKg} kg/bag)\"\n\n")

        sb.append("Age/Day,Date,Feed Consumed,Remaining Feed Stock,Daily Mortality,Live Stock Birds,Body Weight,Remarks\n")

        for (row in rows) {
            val feedCol = "\"${row.feedConsumedDisplay}\""
            val stockCol = "\"${row.remainingFeedDisplay} (${formatNumber(row.remainingFeedKg)} kg)\""
            val remarksClean = "\"${row.remarks.replace("\"", "\"\"")}\""

            sb.append("Day ${row.dayNumber},${row.formattedDate},${feedCol},${stockCol},${row.dailyMortality},${row.runningLiveBirds},\"${row.bodyWeightDisplay}\",${remarksClean}\n")
        }

        return sb.toString()
    }

    /**
     * Generates a clean, WhatsApp/email shareable report.
     */
    fun generateTextReport(
        batch: FlockBatch,
        totalMortality: Int,
        liveBirds: Int,
        mortalityRate: Double,
        remainingBags: Double,
        totalConsumedBags: Double,
        totalConsumedKg: Double,
        rows: List<RegisterBookRow>
    ): String {
        val sb = StringBuilder()
        sb.append("========================================\n")
        sb.append(" 🐔 BIRAJ KHAN POULTRY FARM RECORD\n")
        sb.append(" 100% Offline Safe Ledger Register\n")
        sb.append("========================================\n")
        sb.append("Flock: ${batch.flockName}\n")
        sb.append("Start Date: ${formatDate(batch.startDate)}\n")
        sb.append("Status: ${if (batch.isActive) "ACTIVE FLOCK" else "CLOSED / ARCHIVED"}\n")
        sb.append("----------------------------------------\n")
        sb.append("📊 REAL-TIME FLOCK SUMMARY:\n")
        sb.append("• Initial Chicks Placed: ${batch.initialChicks} birds\n")
        sb.append("• Current Live Birds: ${liveBirds} birds\n")
        sb.append("• Cumulative Mortality: ${totalMortality} birds (${formatNumber(mortalityRate)}%)\n")
        sb.append("• Initial Feed Stock: ${formatNumber(batch.initialFeedBags)} bags\n")
        sb.append("• Total Feed Consumed: ${formatNumber(totalConsumedBags)} bags (${formatNumber(totalConsumedKg)} kg)\n")
        sb.append("• Remaining Feed Stock: ${formatNumber(remainingBags)} bags\n")
        sb.append("----------------------------------------\n")
        sb.append("📖 REGISTER BOOK ENTRIES (${rows.size} Days Logged):\n")

        for (row in rows) {
            sb.append("\n[Day ${row.dayNumber} | ${row.formattedDate}]\n")
            sb.append(" - Feed Consumed: ${row.feedConsumedDisplay}\n")
            sb.append(" - Remaining Stock: ${row.remainingFeedDisplay}\n")
            sb.append(" - Mortality: ${row.dailyMortality} | Live Stock: ${row.runningLiveBirds}\n")
            if (row.bodyWeightDisplay != "—") {
                sb.append(" - Avg Body Weight: ${row.bodyWeightDisplay}\n")
            }
            if (row.remarks != "—") {
                sb.append(" - Remarks: ${row.remarks}\n")
            }
        }

        sb.append("\n========================================\n")
        sb.append("Generated from Biraj Khan Poultry Farm Record App\n")
        return sb.toString()
    }
}

data class RegisterBookRow(
    val log: DailyLog,
    val dayNumber: Int,
    val formattedDate: String,
    val feedConsumedDisplay: String,
    val remainingFeedBags: Double,
    val remainingFeedKg: Double,
    val remainingFeedDisplay: String,
    val dailyMortality: Int,
    val runningLiveBirds: Int,
    val bodyWeightDisplay: String,
    val remarks: String
)

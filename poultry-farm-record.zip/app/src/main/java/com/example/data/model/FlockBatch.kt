package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a poultry flock batch (e.g. Broiler or Layer batch).
 * Persists lifelong safe storage in SQLite Room DB.
 */
@Entity(tableName = "flock_batches")
data class FlockBatch(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val flockName: String = "Flock Batch #1",
    val initialChicks: Int,
    val initialFeedBags: Double,
    val feedBagWeightKg: Double = 50.0,
    val startDate: Long, // Epoch timestamp at midnight
    val isActive: Boolean = true,
    val closedDate: Long? = null,
    val closingNotes: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
